package com.example.medium.Navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.common.navigation.NavigationRoute
import com.example.common.navigation.NavigationSubGraphRoute


@Composable
fun AppNavigation(modifier: Modifier = Modifier, navigationSubGraph: NavigationSubGraph) {
    val navHostController = rememberNavController()
    NavHost(
        navController = navHostController,
        startDestination = NavigationSubGraphRoute.HomeScreen.route
    ) {
        navigationSubGraph.HomeScreenFeature.registerGraph(
            navHostController = navHostController,
            navGraphBuilder = this
        )
        navigationSubGraph.searchScreenFeature.registerGraph(
            navHostController = navHostController,
            navGraphBuilder = this
        )
    }

}