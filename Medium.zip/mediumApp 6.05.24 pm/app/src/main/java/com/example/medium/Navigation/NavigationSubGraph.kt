package com.example.medium.Navigation

import com.example.Navigation.HomeScreenFeature
import com.example.search.ui.Navigation.SearchFeature


data class NavigationSubGraph(
    val HomeScreenFeature: HomeScreenFeature,
    val searchScreenFeature: SearchFeature
)
