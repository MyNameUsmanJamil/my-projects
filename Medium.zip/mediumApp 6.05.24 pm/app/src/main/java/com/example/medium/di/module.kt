package com.example.medium.di


//package com.example.medium.di

import android.content.Context
import com.example.Navigation.HomeScreenFeature


import com.example.medium.Navigation.NavigationSubGraph
import com.example.search.ui.Navigation.SearchFeature
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.realtime.Realtime
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    fun provideNavigationSubGraphs(
        homeScreenFeature: HomeScreenFeature,
        searchScreenFeature: SearchFeature
    ): NavigationSubGraph {
        return NavigationSubGraph(homeScreenFeature, searchScreenFeature)
    }




    @Provides
    @Singleton
    fun provideSupabaseClient(): SupabaseClient {
        return createSupabaseClient(
            supabaseUrl = "https://ugfqtnfohfruiuwydiea.supabase.co",
            supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVnZnF0bmZvaGZydWl1d3lkaWVhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDM4MjI3OTEsImV4cCI6MjA1OTM5ODc5MX0.fHXErqp7DujNivG0z4QiCKTs0i3IYv0uq_jbtnk0IZI"
        ) {
            install(Postgrest)
            install(Realtime) // Agar realtime updates chahiye
//            install(Storage)  // Agar file storage use karna hai
        }
    }












//    @Provides
//    @Singleton
//    fun provideAppDatabase(@ApplicationContext context: Context) = AppDatabase.getInstance(context)
//
//    @Provides
//    fun provideRecipeDao(appDatabase: AppDatabase): RecipeDao {
//        return appDatabase.getRecipeDao()
//    }

}