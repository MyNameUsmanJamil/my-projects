package com.example.common.navigation

sealed class NavigationRoute(val route: String) {

    data object HomeScreenUI : NavigationRoute(route = "/home")
    data object SearchScreenUI : NavigationRoute("/searchScreenUI")
    data object FullSearchScreen : NavigationRoute("/fullSearchScreen")



}

sealed class NavigationSubGraphRoute(val route:String){
    data object HomeScreen: NavigationSubGraphRoute(route = "/main")
    data object SearchScreen: NavigationSubGraphRoute(route = "/search_screen")
}
