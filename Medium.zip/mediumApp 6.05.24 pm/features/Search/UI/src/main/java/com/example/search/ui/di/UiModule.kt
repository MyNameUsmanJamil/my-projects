package com.example.search.ui.di


import com.example.search.ui.Navigation.SearchFeature
import com.example.search.ui.Navigation.SearchFeatureImpl
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@InstallIn(SingletonComponent::class)
@Module
object UiModule {


    @Provides
    fun provideSearchFeatureApi(): SearchFeature {
        return SearchFeatureImpl()
    }

}