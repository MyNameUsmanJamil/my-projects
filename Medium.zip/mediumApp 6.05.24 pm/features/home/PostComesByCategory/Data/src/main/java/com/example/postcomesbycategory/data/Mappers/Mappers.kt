package com.example.postcomesbycategory.data.Mappers

import com.example.postcomesbycategory.data.model.userdataDTO
import com.example.postcomesbycategory.domain.model.AllBlogs

fun List<userdataDTO>.toDomain(): List<AllBlogs> = map {
    AllBlogs(
       id = it.id,
        description = it.description,
        author = it.author
    )
}