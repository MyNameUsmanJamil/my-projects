package com.example.postcomesbycategory.data.Remote

import com.example.postcomesbycategory.data.model.AllBlogsResponse
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface SearchApiService {
// https://www.themealdb.com/api/json/v1/1/search.php?s=chicken

//    @GET("checking")
//    suspend fun getAllBlogs(): Response<AllBlogsResponse>

    // https://www.themealdb.com/api/json/v1/1/lookup.php?i=52771

//    @GET("api/json/v1/1/lookup.php")
//    suspend fun getRecipeDetails(
//        @Query("i") i: String
//    ): Response<RecipeDetailsResponse>

}