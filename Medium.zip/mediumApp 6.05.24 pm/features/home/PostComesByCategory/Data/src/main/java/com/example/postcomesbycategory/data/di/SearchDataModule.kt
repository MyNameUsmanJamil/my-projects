package com.example.postcomesbycategory.data.di

import com.example.postcomesbycategory.data.Remote.SearchApiService
import com.example.postcomesbycategory.data.reposetory.homeReposetoryImpl
import com.example.postcomesbycategory.domain.reposetory.HomeReposetory
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.status.SessionSource
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.realtime.Realtime
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton

const val BASE_URL = "https://www.themealdb.com/"

@InstallIn(SingletonComponent::class)
@Module
object SupabaseModule {



    @Provides
    @Singleton
    fun provideCheckingRepository(client: SupabaseClient): HomeReposetory {
        return homeReposetoryImpl(supabaseClient = client)
    }







//    @Provides
//    @Singleton
//    fun provideRetrofit(): Retrofit {
//        return Retrofit.Builder().baseUrl(BASE_URL)
//            .addConverterFactory(GsonConverterFactory.create())
//            .build()
//    }
//
//    @Provides
//    fun provideSearchApiService(retrofit: Retrofit): SearchApiService {
//        return retrofit.create(SearchApiService::class.java)
//    }



}