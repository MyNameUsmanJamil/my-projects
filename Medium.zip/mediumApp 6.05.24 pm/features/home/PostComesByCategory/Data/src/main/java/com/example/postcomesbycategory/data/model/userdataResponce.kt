package com.example.postcomesbycategory.data.model

data class AllBlogsResponse(
    val AllBlogs: List<userdataDTO>? = null
)

//data class RecipeDetailsResponse(
//    val meals: List<RecipeDTO>? = null
//)