package com.example.postcomesbycategory.data.reposetory

import com.example.postcomesbycategory.data.Mappers.toDomain
import com.example.postcomesbycategory.data.Remote.SearchApiService
import com.example.postcomesbycategory.data.model.userdataDTO
import com.example.postcomesbycategory.domain.model.AllBlogs
import com.example.postcomesbycategory.domain.reposetory.HomeReposetory
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.postgrest

class homeReposetoryImpl(
    private val supabaseClient: SupabaseClient
):HomeReposetory{




    override suspend fun getAllBlogs(): Result<List<AllBlogs>> {
        return try {
            val responce = supabaseClient.postgrest["checking"].select().decodeList<AllBlogs>()
            if (responce.isNotEmpty()){
                Result.success(responce)
            }else{
                Result.failure(Exception("error occurred"))
            }
        }catch (e:Exception){
            Result.failure(Exception("error occurred"))
        }

    }




//    override suspend fun getAllBlogs(): Result<List<AllBlogs>> {
//
//
//        return try {
//            val response = searchApiService.getAllBlogs()  // call yaha pr kar rahay hai
//            if (response.isSuccessful) {
//                response.body()?.AllBlogs?.let {
//                    Result.success(it.toDomain())
//                } ?: run { Result.failure(Exception("error occurred")) }
//            } else {
//                Result.failure(Exception("error occurred"))
//            }
//        } catch (e: Exception) {
//            Result.failure(e)
//        }
//
//
//    }




}