package com.example.postcomesbycategory.domain.reposetory

import com.example.postcomesbycategory.domain.model.AllBlogs
import kotlinx.coroutines.flow.Flow

interface HomeReposetory {

    suspend fun getAllBlogs(): Result<List<AllBlogs>>

}