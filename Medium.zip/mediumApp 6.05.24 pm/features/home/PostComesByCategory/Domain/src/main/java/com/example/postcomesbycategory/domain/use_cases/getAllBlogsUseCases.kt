package com.example.postcomesbycategory.domain.use_cases


import com.example.common.utils.NetworkResult
import com.example.postcomesbycategory.domain.model.AllBlogs
import com.example.postcomesbycategory.domain.reposetory.HomeReposetory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import javax.inject.Inject

class getAllBlogsUseCases @Inject constructor(private val homeRepository: HomeReposetory) {

    operator fun invoke() = flow<NetworkResult<List<AllBlogs>>> {
        emit(NetworkResult.Loading())
        val response = homeRepository.getAllBlogs()
        if (response.isSuccess) {
            emit(NetworkResult.Success(data = response.getOrThrow()))
        } else {
            emit(NetworkResult.Error(message = response.exceptionOrNull()?.localizedMessage))
        }

    }.catch {
        emit(NetworkResult.Error(it.message.toString()))
    }.flowOn(Dispatchers.IO)
}