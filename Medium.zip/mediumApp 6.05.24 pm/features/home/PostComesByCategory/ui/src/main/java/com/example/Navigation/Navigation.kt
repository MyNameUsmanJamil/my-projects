package com.example.Navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.composable
import androidx.navigation.compose.navigation
import androidx.navigation.compose.rememberNavController
import com.example.Screens.HomeScreenUI
import com.example.common.navigation.FeatureApi
import com.example.common.navigation.NavigationRoute
import com.example.common.navigation.NavigationSubGraphRoute
import com.example.Screens.HomeViewModel


interface HomeScreenFeature : FeatureApi


class HomeScreenFeatureImpl : HomeScreenFeature {

    override fun registerGraph(
        navGraphBuilder: NavGraphBuilder,
        navHostController: NavHostController
    ) {



            navGraphBuilder.navigation(
                route = NavigationSubGraphRoute.HomeScreen.route,
                startDestination = NavigationRoute.HomeScreenUI.route
            ) {

                composable(route = NavigationRoute.HomeScreenUI.route) {
                    val viewModel = hiltViewModel<HomeViewModel>()
                    HomeScreenUI(navHostController = navHostController,viewModel = viewModel)
                }


//                composable(route = NavigationRoute.RecipeDetails.route) {
//                    val viewModel = hiltViewModel<RecipeDetailsViewModel>()
//                    val mealId = it.arguments?.getString("id")
//                    LaunchedEffect(key1 = mealId) {
//                        mealId?.let {
//                            viewModel.onEvent(RecipeDetails.Event.FetchRecipeDetails(it))
//                        }
//                    }
//                    RecipeDetailsScreen(
//                        viewModel = viewModel,
//                        onNavigationClick = {
//                            viewModel.onEvent(RecipeDetails.Event.GoToRecipeListScreen)
//                        },
//                        onFavoriteClick = {
//                            viewModel.onEvent(RecipeDetails.Event.InsertRecipe(it))
//                        },
//                        onDelete = {
//                            viewModel.onEvent(RecipeDetails.Event.DeleteRecipe(it))
//                        }, navHostController = navHostController
//                    )
//                }

//                composable(NavigationRoute.FavoriteScreen.route) {
//                    val viewModel = hiltViewModel<FavoriteViewModel>()
//                    FavoriteScreen(
//                        navHostController = navHostController,
//                        viewModel = viewModel,
//                        onClick = { mealId ->
//                            viewModel.onEvent(FavoriteScreen.Event.GoToDetails(mealId))
//                        })
//                }

            }



    }

}