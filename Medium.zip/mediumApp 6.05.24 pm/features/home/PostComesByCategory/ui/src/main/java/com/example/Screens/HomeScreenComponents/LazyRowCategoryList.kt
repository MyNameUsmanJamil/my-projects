package com.example.Screens.HomeScreenComponents

import android.graphics.drawable.Icon
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp




@Composable
fun LazyRowCategoryList(modifier: Modifier = Modifier) {
    val lazyItems = listOf("+", "For You", "Following", "Features", "CryptoCurrency", "Psychology")
    LazyRow(modifier = modifier) {
        items(lazyItems) { item ->
            Text(
                text = item,
                modifier = Modifier
                    .padding(horizontal = 8.dp)
                    .background(Color.LightGray, RoundedCornerShape(12.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                fontSize = 14.sp
            )
        }
    }
}




























//@Composable
//fun LazyRowCategoryList(modifier: Modifier = Modifier) {
//
//    val lazyItems = listOf("+","for you", "following", "features", "CryptoCurrency", "Psychology")
//
//    Column {
//        LazyRow {
//            items(lazyItems){ items ->
//                Text(text = items, modifier = Modifier.padding(end = 10.dp), fontSize = 16.sp)
//            }
//        }
//    }
//}