package com.example.Screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberTopAppBarState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.lifecycle.flowWithLifecycle
import androidx.navigation.NavHostController
import com.example.Screens.HomeScreenComponents.LazyRowCategoryList
import com.example.common.CommonUI.AllBlogsItemUI
import com.example.common.navigation.NavigationRoute
import com.example.common.navigation.NavigationSubGraphRoute
import com.example.common.utils.UiText
import kotlinx.coroutines.flow.collectLatest


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreenUI(navHostController: NavHostController, viewModel: HomeViewModel,) {
    val uiState = viewModel.uiState.collectAsState()
    val scrollBehavior = TopAppBarDefaults.enterAlwaysScrollBehavior(rememberTopAppBarState())
    val navItems = listOf("Home", "Search", "Saved", "Profile")
    var selectedItem by remember { mutableStateOf(0) }


    val lifecycleOwner = LocalLifecycleOwner.current

    LaunchedEffect(key1 = viewModel.navigation) {
        viewModel.navigation.flowWithLifecycle(lifecycleOwner.lifecycle)
            .collectLatest {
                when(it){
                    AllBlogsList.Navigation.GoToSearchScreenUI -> navHostController.navigate(NavigationRoute.SearchScreenUI.route)
                }
            }
    }



    Scaffold(
        modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(navItems[selectedItem]) // Dynamically show screen title
                        Icon(imageVector = Icons.Default.Notifications, contentDescription = null)
                    }
                },
                scrollBehavior = scrollBehavior
            )
        },
        bottomBar = {
            NavigationBar {
                navItems.forEachIndexed { index, label ->
                    NavigationBarItem(
                        selected = selectedItem == index,
                        onClick = { selectedItem = index },
                        icon = {
                            Icon(
                                imageVector = when (label) {
                                    "Home" -> Icons.Default.Home
                                    "Search" -> Icons.Default.Search
                                    "Saved" -> Icons.Default.Favorite
                                    "Profile" -> Icons.Default.Person
                                    else -> Icons.Default.Info
                                },
                                contentDescription = label
                            )
                        },
                        label = { Text(label) }
                    )
                }
            }
        },
        floatingActionButton = {
            FloatingActionButton(onClick = {
                println("Floating Action Button Clicked!") // Replace with Snackbar/Navigation
            }) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add")
            }
        }
    ) { innerPadding ->








        // Screen Content Switch
        when (selectedItem) {
            0 -> HomeContent(innerPadding,uiState)
            1 -> NavigationSubGraphRoute.SearchScreen.route
//            (
//                onSearchClick = { viewModel.onEvent(AllBlogsList.Event.GoToSearchScreen) }
//            )
            2 -> SavedScreen()
            3 -> ProfileScreen()
        }
    }
}





@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeContent(innerPadding: PaddingValues, uiState: State<AllBlogsList.UiState>) {



    if (uiState.value.isLoading)
    {
        Box(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize(), contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator()
        }
    }

    if (uiState.value.error !is UiText.Idle)
    {
        Box(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize(), contentAlignment = Alignment.Center
        ) {
            Text(text = uiState.value.error.getString())
        }
    }





    uiState.value.data?.let{ list ->
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
        ) {
            stickyHeader {
                Surface(
                    color = MaterialTheme.colorScheme.background,
                    shadowElevation = 4.dp
                ) {
                    LazyRowCategoryList(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp)
                    )
                }
            }

            items(list) { index ->
                AllBlogsItemUI(title = "Blog #$index")
            }
        }
    }



}











@Composable
fun SavedScreen() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text("Saved Blogs")
    }
}

@Composable
fun ProfileScreen() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text("User Profile")
    }
}


















//
//@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
//@Composable
//fun HomeScreenUI(modifier: Modifier = Modifier) {
//    val scrollBehavior = TopAppBarDefaults.enterAlwaysScrollBehavior(rememberTopAppBarState())
//
//    Scaffold(
//        modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
//        topBar = {
//            TopAppBar(
//                title = {
//                    Row(
//                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
//                        horizontalArrangement = Arrangement.SpaceBetween,
//                        verticalAlignment = Alignment.CenterVertically
//                    ) {
//                        Text("Home")
//                        Icon(imageVector = Icons.Default.Notifications, contentDescription = null)
//                    }
//                },
//                scrollBehavior = scrollBehavior
//            )
//        }
//    ) { innerPadding ->
//        LazyColumn(
//            modifier = Modifier
//                .padding(innerPadding)
//                .fillMaxSize()
//        ) {
//            // Sticky header for category row
//            stickyHeader {
//                Surface(
//                    color = MaterialTheme.colorScheme.background,
//                    shadowElevation = 4.dp
//                ) {
//                    LazyRowCategoryList(
//                        modifier = Modifier
//                            .fillMaxWidth()
//                            .background(MaterialTheme.colorScheme.background)
//                            .padding(vertical = 8.dp, horizontal = 12.dp)
//                    )
//                }
//            }
//
//            // All blog items
//            items(20) { index ->
//                BlogItem(title = "Blog #$index")
//            }
//        }
//    }
//}
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



//
//@OptIn(ExperimentalMaterial3Api::class)
//@Composable
//fun HomeScreenUI(modifier: Modifier = Modifier) {
//    val scrollBehavior = TopAppBarDefaults.enterAlwaysScrollBehavior(rememberTopAppBarState())
//
//    Scaffold(
////        modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
//        topBar = {
//            TopAppBar(
//                colors = TopAppBarDefaults.topAppBarColors(
//                    containerColor = MaterialTheme.colorScheme.primaryContainer,
//                    titleContentColor = MaterialTheme.colorScheme.primary,
//                ),
//                title = {
//                    Row(
//                        modifier =  Modifier.fillMaxWidth().padding(horizontal = 12.dp),
//                        horizontalArrangement = Arrangement.SpaceBetween,
//                        verticalAlignment = Alignment.CenterVertically
//                    ) {
//                        Text("Home")
//                        Icon(imageVector = Icons.Default.Notifications, contentDescription = null)
//                    }
//                    },
////                scrollBehavior = scrollBehavior
//            )
//        }
//    ) { innerPadding ->
//        Column(
//            modifier = Modifier
//                .padding(innerPadding)
//                .fillMaxSize()
//                .verticalScroll(rememberScrollState())
//        ) {
//            LazyRowCategoryList()
//            AllBlogs()
//        }
//    }
//}