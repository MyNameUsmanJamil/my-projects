package com.example.Screens

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.common.utils.NetworkResult
import com.example.common.utils.UiText
import com.example.postcomesbycategory.domain.model.AllBlogs
import com.example.postcomesbycategory.domain.use_cases.getAllBlogsUseCases
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject


@HiltViewModel
class HomeViewModel @Inject constructor(
    private val getAllBlogsUseCase: getAllBlogsUseCases
) : ViewModel() {

    private val _uiState = MutableStateFlow(AllBlogsList.UiState())
    val uiState: StateFlow<AllBlogsList.UiState> get() = _uiState.asStateFlow()

    private val _navigation = Channel<AllBlogsList.Navigation>()
    val navigation: Flow<AllBlogsList.Navigation> = _navigation.receiveAsFlow()

    fun onEvent(event: AllBlogsList.Event) {
        when (event) {
            is AllBlogsList.Event.SearchAllBlogs -> {
                search(event.q)
            }

            is AllBlogsList.Event.GoToSearchScreen -> {
                viewModelScope.launch {
                    _navigation.send(AllBlogsList.Navigation.GoToSearchScreenUI)
                }
            }


        }
    }


    private fun search(q: String) = getAllBlogsUseCase.invoke()
        .onEach { result ->
            when (result) {
                is NetworkResult.Loading -> {
                    _uiState.update { AllBlogsList.UiState(isLoading = true) }
                }

                is NetworkResult.Error -> {
                    _uiState.update { AllBlogsList.UiState(error = UiText.RemoteString(result.message.toString())) }

                }

                is NetworkResult.Success -> {
                    _uiState.update { AllBlogsList.UiState(data = result.data) }

                }
            }

        }.launchIn(viewModelScope)


}

object AllBlogsList {

    data class UiState(
        val isLoading: Boolean = false,
        val error: UiText = UiText.Idle,
        val data: List<AllBlogs>? = null
    )

    sealed interface Navigation {

        data object GoToSearchScreenUI : Navigation



    }

    sealed interface Event {
        data class SearchAllBlogs(val q: String) : Event

        data object GoToSearchScreen : Event

    }

}