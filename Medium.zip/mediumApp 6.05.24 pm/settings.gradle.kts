pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven("https://maven.pkg.jetbrains.space/public/p/compose/dev")
    }
}

rootProject.name = "Medium"
include(":app")
include(":features:Search:data")
include(":features:YourLibrary:ui")
include(":features:Profile:ui")
include(":features:Home:PostComesByCategory:Data")
include(":features:Home:PostComesByCategory:Domain")
include(":features:Home:PostComesByCategory:ui")
include(":common")
include(":features:Search:UI")
