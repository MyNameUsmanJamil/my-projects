package com.example.common.CommonUI

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MailOutline
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp




@Composable
fun AllBlogsItemUI(title: String) {
    Column(
        modifier = Modifier
            .padding(vertical = 8.dp, horizontal = 12.dp)
            .fillMaxWidth()
            .height(100.dp)
            .background(Color.Gray, shape = RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Row {
            Icon(imageVector = Icons.Default.Star, contentDescription = null)
            Text(text = title, modifier = Modifier.padding(start = 5.dp), fontSize = 12.sp)
        }
        Text("Android Development Roadmap 2025")
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("April 3")
                Spacer(modifier = Modifier.width(8.dp))
                Icon(imageVector = Icons.Default.ThumbUp, contentDescription = null)
                Text("1")
                Spacer(modifier = Modifier.width(8.dp))
                Icon(imageVector = Icons.Default.MailOutline, contentDescription = null)
                Text("1")
            }
            Row {
                Icon(imageVector = Icons.Default.Info, contentDescription = null)
                Icon(imageVector = Icons.Default.MoreVert, contentDescription = null)
            }
        }
    }
}


































//
//@Composable
//fun AllBlogs(modifier: Modifier = Modifier) {
//
//    val lazyItems = listOf("+","for you", "following", "features", "CryptoCurrency", "Psychology","11","2","3","4")
//
//
//            LazyColumn {
//                items(lazyItems){ items ->
//                   Column (
//                       modifier = Modifier
//                           .padding(top = 10.dp)
//                           .fillMaxWidth()
//                           .height(100.dp)
//                           .background(Color.Gray)
//
//
//
//                   ){
//                       Row {
//                           Icon(imageVector = Icons.Default.Star, contentDescription = null)
//                           Text(text = items, modifier = Modifier.padding(start = 5.dp), fontSize = 12.sp)
//                       }
//                       Text("Android Development Roadmap 2025")
//                       Row (
//                           horizontalArrangement = Arrangement.SpaceBetween,
//                           verticalAlignment = Alignment.CenterVertically
//                       ){
//                           Row (
//                               verticalAlignment = Alignment.CenterVertically
//                           ){
//                               Text("April 3")
//                               Row {
//                                   Icon(imageVector = Icons.Default.ThumbUp, contentDescription = null)
//                                   Text("1")
//                               }
//                               Row {
//                                   Icon(imageVector = Icons.Default.MailOutline, contentDescription = null)
//                                   Text("1")
//                               }
//                           }
//                           Row {
//                               Icon(imageVector = Icons.Default.Info, contentDescription = null)
//                               Icon(imageVector = Icons.Default.MoreVert, contentDescription = null)
//
//                           }
//                       }
//
//                   }
//                }
//            }
//
//
//}