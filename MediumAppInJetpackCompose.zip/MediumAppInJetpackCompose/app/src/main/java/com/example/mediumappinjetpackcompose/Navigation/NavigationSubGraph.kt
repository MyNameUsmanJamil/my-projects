package com.example.mediumappinjetpackcompose.Navigation

import com.example.homes.ui.Navigation.HomeScreenFeature
import com.example.searchs.ui.Navigation.SearchFeature


data class NavigationSubGraph(
    val HomeScreenFeature: HomeScreenFeature,
    val searchScreenFeature: SearchFeature
)
