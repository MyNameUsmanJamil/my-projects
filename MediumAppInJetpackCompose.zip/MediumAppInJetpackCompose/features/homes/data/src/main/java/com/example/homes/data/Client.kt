package com.example.homes.data

//import io.github.jan.supabase.createSupabaseClient
//import io.github.jan.supabase.postgrest.Postgrest


//val supabase = createSupabaseClient(
//    supabaseUrl = "https://ugfqtnfohfruiuwydiea.supabase.co",
//    supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVnZnF0bmZvaGZydWl1d3lkaWVhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDM4MjI3OTEsImV4cCI6MjA1OTM5ODc5MX0.fHXErqp7DujNivG0z4QiCKTs0i3IYv0uq_jbtnk0IZI"
//) {
////    install(Auth)
//    install(Postgrest)
//    //install other modules
//}

