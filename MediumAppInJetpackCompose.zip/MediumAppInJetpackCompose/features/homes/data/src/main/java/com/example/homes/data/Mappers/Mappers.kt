package com.example.homes.data.Mappers

import com.example.homes.data.model.userdataDTO
import com.example.homes.domain.model.AllBlogs

fun List<userdataDTO>.toDomain(): List<AllBlogs> = map {
    AllBlogs(
       id = it.id,
        description = it.description,
        author = it.author
    )
}