package com.example.homes.data.Remote

interface SearchApiService {
// https://www.themealdb.com/api/json/v1/1/search.php?s=chicken

//    @GET("checking")
//    suspend fun getAllBlogs(): Response<AllBlogsResponse>

    // https://www.themealdb.com/api/json/v1/1/lookup.php?i=52771

//    @GET("api/json/v1/1/lookup.php")
//    suspend fun getRecipeDetails(
//        @Query("i") i: String
//    ): Response<RecipeDetailsResponse>

}