package com.example.homes.data.di

import com.example.homes.data.reposetory.homeReposetoryImpl
import com.example.homes.data.supabaseApi.createSupabaseClient
import com.example.homes.domain.reposetory.HomeReposetory
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import io.github.jan.supabase.SupabaseClient

import io.github.jan.supabase.postgrest.Postgrest
import javax.inject.Singleton



@Module
@InstallIn(SingletonComponent::class)
object SupabaseModule {

    @Provides
    @Singleton
    fun provideSupabaseClient(): SupabaseClient {
        return createSupabaseClient(
            supabaseUrl = "https://ugfqtnfohfruiuwydiea.supabase.co",
            supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVnZnF0bmZvaGZydWl1d3lkaWVhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDM4MjI3OTEsImV4cCI6MjA1OTM5ODc5MX0.fHXErqp7DujNivG0z4QiCKTs0i3IYv0uq_jbtnk0IZI"
        )
    }




    @Provides
    @Singleton
    fun provideHomeRepository(
        impl: homeReposetoryImpl
    ): HomeReposetory = impl





}




















//const val BASE_URL = "https://www.themealdb.com/"
//
//@InstallIn(SingletonComponent::class)
//@Module
//object SupabaseModule {
//
//
//
//
//    @Provides
//    @Singleton
//    fun provideSupabaseClient(): SupabaseClient {
//        return createSupabaseClient()
//    }












//    @Provides
//    @Singleton
//    fun provideRetrofit(): Retrofit {
//        return Retrofit.Builder().baseUrl(BASE_URL)
//            .addConverterFactory(GsonConverterFactory.create())
//            .build()
//    }
//
//    @Provides
//    fun provideSearchApiService(retrofit: Retrofit): SearchApiService {
//        return retrofit.create(SearchApiService::class.java)
//    }



//}