package com.example.homes.data.model

import kotlinx.serialization.Serializable


@Serializable
data class userdataDTO(
    val id: Int?,
    val description: String?,
    val author: String?
)





