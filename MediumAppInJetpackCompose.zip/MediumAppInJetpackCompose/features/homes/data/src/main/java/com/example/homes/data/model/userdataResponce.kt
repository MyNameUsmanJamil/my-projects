package com.example.homes.data.model

import com.example.homes.data.model.userdataDTO

data class AllBlogsResponse(
    val AllBlogs: List<userdataDTO>? = null
)

//data class RecipeDetailsResponse(
//    val meals: List<RecipeDTO>? = null
//)