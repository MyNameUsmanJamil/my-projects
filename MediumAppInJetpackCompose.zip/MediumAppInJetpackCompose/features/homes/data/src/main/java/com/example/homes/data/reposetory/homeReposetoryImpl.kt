package com.example.homes.data.reposetory

import com.example.homes.domain.model.AllBlogs
import com.example.homes.domain.reposetory.HomeReposetory
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.postgrest

class homeReposetoryImpl(
    private val supabaseClient: SupabaseClient
): HomeReposetory {




    override suspend fun getAllBlogs(): Result<List<AllBlogs>> {
        return try {
            val responce = supabaseClient.postgrest["checking"].select().decodeList<AllBlogs>()
            if (responce.isNotEmpty()){
                Result.success(responce)
            }else{
                Result.failure(Exception("No blogs found"))
            }
        }catch (e:Exception){
            Result.failure(Exception("error occurred ${e.message}"))
        }

    }




//    override suspend fun getAllBlogs(): Result<List<AllBlogs>> {
//
//
//        return try {
//            val response = searchApiService.getAllBlogs()  // call yaha pr kar rahay hai
//            if (response.isSuccessful) {
//                response.body()?.AllBlogs?.let {
//                    Result.success(it.toDomain())
//                } ?: run { Result.failure(Exception("error occurred")) }
//            } else {
//                Result.failure(Exception("error occurred"))
//            }
//        } catch (e: Exception) {
//            Result.failure(e)
//        }
//
//
//    }




}