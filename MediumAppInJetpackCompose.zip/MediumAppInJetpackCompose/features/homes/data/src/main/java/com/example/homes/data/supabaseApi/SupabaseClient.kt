package com.example.homes.data.supabaseApi

import io.github.jan.supabase.SupabaseClient


object SupabaseConfig {
    const val SUPABASE_URL = "https://your-project.supabase.co"
    const val SUPABASE_KEY = "your-anon-key"
}

fun createSupabaseClient(
    supabaseUrl: String = SupabaseConfig.SUPABASE_URL,
    supabaseKey: String = SupabaseConfig.SUPABASE_KEY,
    init: SupabaseClient.Builder.() -> Unit = {}
): SupabaseClient {
    return SupabaseClient(
        supabaseUrl = supabaseUrl,
        supabaseKey = supabaseKey
    ) {
        install(Postgrest)
        // Add other plugins like Realtime if needed
        // install(Realtime)
        init()
    }
}