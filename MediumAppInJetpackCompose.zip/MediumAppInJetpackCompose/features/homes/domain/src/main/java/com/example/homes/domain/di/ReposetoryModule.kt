package com.example.homes.domain.di

//import com.example.homes.data.reposetory.homeReposetoryImpl
//import com.example.homes.domain.reposetory.HomeReposetory
//import dagger.Module
//import dagger.Provides
//import dagger.hilt.InstallIn
//import dagger.hilt.components.SingletonComponent
//import io.github.jan.supabase.SupabaseClient
//import javax.inject.Singleton

//@Module
//@InstallIn(SingletonComponent::class)
//object RepositoryModule {
//
//    @Provides
//    @Singleton
//    fun provideHomeRepository(
//        client: SupabaseClient
//    ): HomeReposetory {
//        return homeReposetoryImpl(client)
//    }
//}