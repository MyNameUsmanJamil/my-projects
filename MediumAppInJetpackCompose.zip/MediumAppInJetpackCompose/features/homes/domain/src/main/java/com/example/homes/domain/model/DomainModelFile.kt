package com.example.homes.domain.model


data class AllBlogs(
    val id: Int?,
    val description: String?,
    val author: String?
)