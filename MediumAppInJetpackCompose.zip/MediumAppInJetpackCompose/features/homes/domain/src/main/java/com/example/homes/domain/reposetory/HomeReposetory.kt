package com.example.homes.domain.reposetory

import com.example.homes.domain.model.AllBlogs

interface HomeReposetory {

    suspend fun getAllBlogs(): Result<List<AllBlogs>>

}