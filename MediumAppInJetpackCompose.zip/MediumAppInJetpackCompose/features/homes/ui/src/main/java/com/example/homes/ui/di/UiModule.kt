package com.example.homes.ui.di

import com.example.homes.ui.Navigation.HomeScreenFeature
import com.example.homes.ui.Navigation.HomeScreenFeatureImpl
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@InstallIn(SingletonComponent::class)
@Module
object UiModule {


    @Provides
    fun provideSearchFeatureApi(): HomeScreenFeature {
        return HomeScreenFeatureImpl()
    }

}