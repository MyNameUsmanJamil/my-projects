package com.example.searchs.ui.Navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.composable
import androidx.navigation.navigation
import com.example.common.navigation.FeatureApi
import com.example.common.navigation.NavigationRoute
import com.example.common.navigation.NavigationSubGraphRoute
import com.example.searchs.ui.Screens.FullSearchScreen
import com.example.searchs.ui.Screens.SearchScreen

interface SearchFeature : FeatureApi

class SearchFeatureImpl : SearchFeature {
    override fun registerGraph(
        navGraphBuilder: NavGraphBuilder,
        navHostController: NavHostController
    ) {
        navGraphBuilder.navigation(
            route = NavigationSubGraphRoute.SearchScreen.route,
            startDestination = NavigationRoute.SearchScreenUI.route
        ) {

            composable(route = NavigationRoute.SearchScreenUI.route) {
                    SearchScreen(
                        onSearchClick = { navHostController.navigate(NavigationRoute.FullSearchScreen.route) }
                    )
            }


            composable(route = NavigationRoute.FullSearchScreen.route) {
                FullSearchScreen(
                    onBackClick = { navHostController.navigate(NavigationRoute.SearchScreenUI.route) }
                )
            }

        }
    }
}
