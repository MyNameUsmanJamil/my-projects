pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "MediumAppInJetpackCompose"
include(":app")
include(":Common")
include(":features:homes:ui")
include(":features:profiles:ui")
include(":features:favorites:ui")
include(":features:searchs:ui")
include(":features:homes:data")
include(":features:homes:domain")
include(":features:favorites:data")
include(":features:favorites:domain")
include(":features:profiles:data")
include(":features:profiles:domain")
include(":features:searchs:data")
include(":features:searchs:domain")
