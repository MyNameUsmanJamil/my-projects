package gaur.himanshu.search.data.model

data class RecipeResponse(
    val meals: List<RecipeDTO>? = null
)

data class RecipeDetailsResponse(
    val meals: List<RecipeDTO>? = null
)